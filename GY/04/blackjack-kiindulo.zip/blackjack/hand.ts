class Hand {
    constructor(public cards: Card[], public showFirst: boolean) {
    }

    get value(): number {
        let value = 0;
        let aces = 0;
        for (let card of this.showFirst ? this.cards : this.cards.slice(1)) {
            switch (card.value) {
                case "KING":
                case "QUEEN":
                case "JACK":
                case "10":
                    value += 10;
                    break;
                case "ACE":
                    aces++;
                    value += 11;
                    break;
                default:
                    const cardValue = parseInt(card.value);
                    if (cardValue > 1)
                        value += cardValue;
                    else
                        console.error(`Unknown card value: ${card.value} (${card.code})`);
                    break;
            }
        }
        // TODO: ász érhessen 1-et is, ha túllépnénk vele a 21-et!
        return value;
    }
}
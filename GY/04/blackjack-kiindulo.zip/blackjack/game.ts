class Game {
    private constructor(public readonly deckId: string) {
    }

    static readonly apiBaseUrl = "https://deckofcardsapi.com/api/";

    static async NewGame(deckCount: number = 6) {
        var response = await this.NewDeck(deckCount);
        return new Game(response.deck_id);
    }

    static async NewDeck(deckCount: number) {
        return await this.Call<NewDeckResponse>(`deck/new/shuffle/?deck_count=${deckCount}`);
    }

    async Draw(count: number = 1) {
        return await Game.Call<DrawCardResponse>(`deck/${this.deckId}/draw/?count=${count}`);
    }

    private static async Call<ResponseType extends DeckOfCardsResponse>(relativeUrl: string) {
        const response = await fetch(`${this.apiBaseUrl}${relativeUrl}`);
        const responseJson: ResponseType = await response.json();
        if (!responseJson.success) {
            console.error("Error from Deck Of Cards API:", responseJson);
        }
        return responseJson;
    }

    dealersHand: Hand = new Hand([], false);
    playersHand: Hand = new Hand([], true);
}
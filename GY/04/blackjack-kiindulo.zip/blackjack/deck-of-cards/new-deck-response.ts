interface NewDeckResponse extends DeckOfCardsResponse {
    shuffled: boolean;
}

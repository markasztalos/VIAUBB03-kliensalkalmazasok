interface DrawCardResponse extends DeckOfCardsResponse {
    cards: Card[];
}

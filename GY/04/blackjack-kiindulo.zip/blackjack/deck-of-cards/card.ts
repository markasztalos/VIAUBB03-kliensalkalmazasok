interface Card {
    image: string;
    value: Rank;
    suit: Suit;
    code: string;
    images: { [key: string]: string }
}

interface DeckOfCardsResponse {
    success: boolean;
    deck_id: string;
    remaining: number;
}
